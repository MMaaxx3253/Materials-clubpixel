
# nature-helper

Этот проект (сайт) о том как сделать природе лучше и помочь ей



## Дэмо сайта

Сори, я его пока не сделал :D



## Скачивание и установка необходимых библиотек

Для скачивания в git bash (или в терминале если у вас стоит пингвин) введите в него следующее

```bash
git clone https://github.com/MMaaxx3253/nature-helper
cd nature-helper
```
Затем впишите следующее:
```bash
pip install flask #необходим для работы сайта и формы
```
Далее зайдите в папку с проектом и откройте файл main.py

![image](https://github.com/user-attachments/assets/5190e476-5c71-4bd0-8d25-1f94bada7abf)

(Если у вас для пайтон не сделан по умолчанию VSCode то правой кнопкой мыши по main.py и нажать "Открыть в Code" ну или "Open with Code")

![image](https://github.com/user-attachments/assets/a42fa911-395e-41fd-af78-6a2cdf9c7acb)

Далее запустите файл с помощью стрелки справа сверху (убедитесь что в vscode у вас есть расширение Python)

![image](https://github.com/user-attachments/assets/90bac20f-b3a1-41b4-9667-ce2596aef1b4)

У вас должно получится так (там будет текст с приветствием если в первый раз):

![image](https://github.com/user-attachments/assets/424c2101-50c9-4bc9-8c91-15fcbda442c7)

Вуаля! Сайт запущен!
