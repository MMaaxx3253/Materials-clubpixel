from flask import Flask, render_template, redirect, url_for, request
from collections import namedtuple
app = Flask(__name__)
Message = namedtuple("Message", "text image description")
messagesList = []
@app.route("/", methods=["GET"])
def start_page():
    return render_template("index.html", messages=messagesList)
@app.route("/add", methods=["POST"])
def add():
    text=request.form["text"]
    image=request.form["image"]
    description=request.form["description"]
    if text != "" and image != "" and description != "":
        messagesList.append(Message(text, image, description))
    return redirect(url_for("start_page"))
@app.route("/about", methods=["GET"] )
def about_page():
    return render_template("about.html")
if __name__ == "__main__":
    app.run()