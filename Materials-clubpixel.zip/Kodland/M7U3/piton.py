import speech_recognition as sr

# obtain audio from the microphone
r = sr.Recognizer()

with sr.Microphone() as source:
    print("Говорите...")
    r.adjust_for_ambient_noise(source) 
    audio = r.listen(source)

    try:
        r_speech = r.recognize_google(audio, language="ru-RU")
        print("Вы сказали: " + r_speech)
    except sr.UnknownValueError:
        print("Речь не распознана")
    except sr.RequestError as e:
        print(f"Ошибка сервиса Google Speech Recognition; {e}")