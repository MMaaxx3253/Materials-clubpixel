#E-System by MINEMaxx
import time
import os
from colorama import init, Fore
from colorama import Style
os.system('cls')
startup = "E-System BIOS, welcome!"
print(startup)
time.sleep(2)
print("Searching bootable disk...")
time.sleep(1)
print("Booting up from Hard Disk...")
time.sleep(0.2)
os.system('cls')
print("╔═══╗─╔═══╗")
print("║╔══╝─║╔═╗║")
print("║╚══╗─║╚══╦╗─╔╦══╗")
print("║╔═╦╩═╬══╗║║─║║══╣")
print("║╚═╩╦═╣╚═╝║╚═╝╠══║")
print("╚═══╝─╚═══╩═╗╔╩══╝")
print("──────────╔═╝║")
print("──────────╚══╝")
print("E-Systems company © E-Sys 2024 @ RU")
print("Preparing...")
time.sleep(5)
while True:  # Цикл для повторных попыток
    login = input("Логин: ")

    if login == "E-Sys":  # Правильное сравнение с одним знаком равенства
        password = input("Пароль: ")

        if password == "pass":
            print("Вы вошли!")
            break  # Выход из цикла при успешном входе
        else:
            print("Пароль неверен! Попробуйте ещё раз")
    else:
        print("Логин неверен! Попробуйте ещё раз")

while True:
    cmd = input("dsk1: ")
    if cmd == "exit":
        break
    elif cmd == "cat":
        print("Мяу😺")
    elif cmd == "shutdown":
        os.system('cls')
        print("Выключение.")
        time.sleep(1)
        os.system('cls')
        print("Выключение..")
        time.sleep(1)
        os.system('cls')
        print("Выключение...")
        time.sleep(1)
        os.system('cls')
        print("Выключение..")
        time.sleep(1)
        os.system('cls')
        print("Выключение.")
        time.sleep(1)
        print("Пожалуйста, впишите exit")
        break
    elif cmd == "how":
        print("Я сделал вход с Bard (уже Gemini)! (https://bard.google.com)")
    elif cmd == "help":
        print("Не реализовано!")
    elif cmd == "dog":
        print("Гаф🐶")
    elif cmd == "dir":
        print("List of files on dsk1:")
        print(Fore.RED + "Папка,", Fore.BLUE + "файл")
        print()
        print(Fore.RED + "System")
        print(Fore.RED + "Users")
        print(Fore.BLUE + "readme.txt")
        print(Fore.BLUE + "rus.script")
        print(Fore.BLUE + "eng.script")
        print(Fore.BLUE + "crashsrv.script")
        print()
        print(Style.RESET_ALL + "2 файла, 2 директории")
    elif cmd == "read readme.txt":
        print("read: ошибка, пустой файл")
    elif cmd == "echo":
        print("Команда не готова!")
    elif cmd == "rmcomp cpu":
        aus = input("Это критический компонент системы! Вы действительно хотите это сделать? (Y/N) ")
        if aus == "y" or "Y":
            print("Попытка выключения ЦП...")
            time.sleep(2)
            os.system('cls')
            cpunotin = True
            print("CRITICAL ALERT: CPU undefined, restarting...")
            time.sleep(1)
            print("ouvFY GO*UILHFYBFUksdkhUOFILGYINOILUGY")
            time.sleep(0.5)
            print("OYIBKIYbuirkiloJUHOGNflkiuzsnhoilPFJGOUke09yru89-")
            time.sleep(0.5)
            print("OUFHBUOIFGOByiye079pBPYTN&(PionjIPLkfuhGN(&OR))")
            time.sleep(0.5)
            print("UOHFUIBT&*$OIUHfuy bTGRUIONbhoiBtyIB^R&*(shjbG*)B&")
            time.sleep(0.5)
            print("iUYRB&^*IVU Ygf9B*^&IVTRUG*ONBi76B(V*T*^RBVT(WB^*&R^*))")
            time.sleep(0.5)
            print("OYBR*&OUR YIBDNOYIBUFRUOBYDVTRTEYUOVB^U$")
            time.sleep(0.5)
            print("TUWEHFGIRTUIFGI KugASI&uYG T&*go8 ABGTO& OYUFGo7^( CTgO&(^TG(O^CR&)))")
            time.sleep(0.5)
            print("ouvFY GO*UILHFYBFUksdkhUOFILGYINOILUGY")
            time.sleep(0.5)
            print("OYIBKIYbuirkiloJUHOGNflkiuzsnhoilPFJGOUke09yru89-")
            time.sleep(0.5)
            print("OUFHBUOIFGOByiye079pBPYTN&(PionjIPLkfuhGN(&OR))")
            time.sleep(0.5)
            print("UOHFUIBT&*$OIUHfuy bTGRUIONbhoiBtyIB^R&*(shjbG*)B&")
            time.sleep(0.5)
            print("iUYRB&^*IVU Ygf9B*^&IVTRUG*ONBi76B(V*T*^RBVT(WB^*&R^*))")
            time.sleep(0.5)
            print("OYBR*&OUR YIBDNOYIBUFRUOBYDVTRTEYUOVB^U$")
            time.sleep(0.5)
            print("TUWEHFGIRTUIFGI KugASI&uYG T&*go8 ABGTO& OYUFGo7^( CTgO&(^TG(O^CR&)))")
            time.sleep(0.5)
            if cpunotin == True:
                os.system('rus.py')
        if aus == "n" or "N":
            print("Okay :)")
        else:
            print("Please Y or N")
    elif cmd == "rus.script":
        print("ОС уже Руссифицирована!")
    elif cmd == "eng.script":
        print("Переключить язык на английский?")
        dit = input("(Y)Да или (N)Нет: ")
        if dit == "y" or "Y":
            print("Удаление Русского пакета...")
            time.sleep(3)
            print("Sucess, restart required to apply the changes, giving command...")
            time.sleep(2)
            os.system('cls')
            print("Выключение.")
            time.sleep(1)
            os.system('cls')
            print("Выключение..")
            time.sleep(1)
            os.system('cls')
            print("Выключение...")
            time.sleep(1)
            os.system('cls')
            print("Выключение..")
            time.sleep(1)
            os.system('cls')
            print("Выключение.")
            time.sleep(1)
            os.system("start.py")
        if dit == "n" or "N":
            print("Отменяю...")
    elif cmd == "crashsrv.script":
        print("Какой сервер вы хотите крашнуть? (Dos)")
        srv2crash = input(print("Введите IP или адрес (пример: example.e-sys.co или 73.178.1.254): "))
        print("Ваш выбор: ", srv2crash)
        print("Поиск сервера...")
        os.system(f'ping {srv2crash}')
        print("Сервер был обнаружен?")
        yorn = input(print("Y/N? "))
        if yorn == "y" or "Y":
            print("Поиск метода взлома...")
            print("Try method 00000000000A")
            time.sleep(0.2)
            print("Try method 00000000000B")
            time.sleep(0.2)
            print("Try method 00000000000C")
            time.sleep(0.2)
            print("Try method 61543956580V")
            time.sleep(0.2)
            print("Try method 06210683764A")
            time.sleep(0.2)
            print("Try method 62041WE6DDTW")
            time.sleep(0.2)
            print("Try method 478560H8G965")
            time.sleep(0.2)
            print("Try method 6GH34F876G9B")
            time.sleep(0.2)
            print("Try method 78ERTWI87VWE")
            time.sleep(0.2)
            print("Try method 5F69569HN7H7")
            time.sleep(0.2)
            print("Try method 78R6ET78695F")
            time.sleep(0.2)
            print("Try method 76ETF785E845")
            time.sleep(0.2)
            print("Try method 67D0976E8976")
            time.sleep(0.2)
            print("Try method E6G489FG5656")
            time.sleep(0.2)
            print("Try method TED6IRTBV6TE")
            time.sleep(0.2)
            print("Try method 87456F6TE6BF")
            time.sleep(5)
            print("ERR_BANNED LOG: Dos attack detected! ip is banned")
        else:
            print("Выход из програмы краша серверов...")
    else:
       print("Неверная команда или файл!")