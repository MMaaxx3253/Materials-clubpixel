import discord

# Переменная intents - хранит привилегии бота
intents = discord.Intents.default()
# Включаем привелегию на чтение сообщений
intents.message_content = True
# Создаем бота в переменной client и передаем все привелегии
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'We have logged in as {client.user}')

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    if message.content.startswith('$hello'):
        await message.channel.send(f'Привет! Я бот {client.user}!')
    elif message.content.startswith('$bye'):
        await message.channel.send("")
    elif message.content.startswith('$nick'):
        await message.channel.send(f"My nickname is {client.user}")
    elif  message.content.startswith('$heh'):
        if len(message.content) > 4:
            count_heh = int(message.content[4:])
        else:
            count_heh = 5
        await message.channel.send("he" * count_heh)
    else:
        await message.channel.send(message.content)
    

client.run("MTIwNjIwNjQzMjQyOTc0NDE0OA.GRjIkR.FrFnY5_97gAvc3EPfs9KF69gsmlNo2BV3MQ2-k")