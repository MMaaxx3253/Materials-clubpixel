let player = document.querySelector(".player")
let enemy = document.querySelector(".enemy")
document.addEventListener("keydown", function(){
    if (player.classList != "jump"){
        player.classList.add("jump")
    
    }
    setTimeout(function(){
        document.querySelector(".scores").innerHTML = ++scores
        player.classList.remove("jump")
    }, 500)
    
})
let scores = 0
alert("Нажмите кнопку, чтобы начать!")
setInterval(function(){
    let playerTop = parseInt(window.getComputedStyle(player).getPropertyValue("top"))
    let enemyLeft = parseInt(window.getComputedStyle(enemy).getPropertyValue("Left"))

    if (enemyLeft < 50 && enemyLeft > 0 && playerTop >= 140){
        alert("Проиграл!")
        alert("У тебя очков: " + scores)
        document.location.reload()
    }
}, 10)