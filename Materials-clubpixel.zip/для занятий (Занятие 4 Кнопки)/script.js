let b1 = document.querySelector(".b1")

b1.addEventListener("click", function(){
    alert("Ха, нажал :D")
})

let text = document.querySelector(".text")

b1.addEventListener("click", function(){
    text.innerHTML = "ОПА!"
})