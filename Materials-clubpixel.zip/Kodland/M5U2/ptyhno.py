words = ["СЛОВО", "Слово", "СлОвО", "сЛОВО"]
lowercase_words = []

for word in words:
    if word.isalpha():
        lowercase_words.append(word.lower())

print(lowercase_words)