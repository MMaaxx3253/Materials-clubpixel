// const userName = "Макс Ком"
// let age = 11
// // console.log("Имя: ", userName)
// // console.log("Лет: ", age)
// userName = "Макс Ком"
// age = 11
// console.log("Имя: ", userName)
// console.log("Лет: ", age)

// let a = 2
// let b = 2

// if (a > b) {
//     console.log("А больше Б")
// }
// else if (a < b) {
//     console.log("А меньше Б")
// }
// else {
//     console.log("А и Б равны")
// }

alert("Чтобы войти в админку...")
let login = prompt("Введи логин админа:")
let password = prompt("А те(пе)рь пароль!")

if (login == "MINEMaxx" && password == "AdminIsOff"){
    alert("Вы вошли!")
}
else{
    alert("Не вошёль :)")
    document.location.reload()
}
function example(text){
    console.log(text)
}

example("Function with argumentss dead")
example("alive*")