while True:
    choice = input("Выберите скрипт (1/2/3)")
    if choice == "1":
        my_words = ["Hi", "Python Pro", "Kodland"]
        while True:
            choice2 = input("Выберите слово: ")
            if choice2 == "1":
                print(my_words[0])
            elif choice2 == "2":
                print(my_words[1])
            elif choice2 == "3":
                print(my_words[2])
            elif choice2 == "exit":
                break
            else:
                print("NO")
    elif choice == "2":
        name = input("Ваше имя:")
        print("Прив ", name)
    elif choice == "3":
        import random
        emojis = ["^^", "0_o", ":)", "¯\\_(ツ)_/¯", "(￢_￢)"]
        print(random.choice(emojis))
    else:
        print("НЕВЕРНО")