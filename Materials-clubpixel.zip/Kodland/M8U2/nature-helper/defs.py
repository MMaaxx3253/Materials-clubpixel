import os
import time
def startup():
    print("Welcome text not shown due to non-first time")
    print("Please wait, we are now starting.")
    time.sleep(1)
    os.system("cls")
    print("Please wait, we are now starting..")
    time.sleep(1)
    os.system("cls")
    print("Please wait, we are now starting...")
    time.sleep(1)
    os.system("cls")

# Do not pay attetion at this symbol below, it is commented to prevent script from crashing
# 