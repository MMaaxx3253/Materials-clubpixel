import os
import time
passwa = "prosto_lifelawon1448"
logea = "ProstoV"
passwu = "Big_D@ddy69"
logeu = "MakeMeButter"
def kodland(admin):
    print("╭╮╭━╮╱╱╱╱╭┳╮╱╱╱╱╱╱╱╱╭╮")
    print("┃┃╭╯╱╱╱╱┃┃┃╱╱╱╱╱╱╱╱┃┃")
    print("┃╰╯╯╭━━┳━╯┃┃╭━━┳━╮╭━╯┃")
    print("┃╭╮┃┃╭╮┃╭╮┃┃┃╭╮┃╭╮┫╭╮┃")
    print("┃┃┃╰┫╰╯┃╰╯┃╰┫╭╮┃┃┃┃╰╯┃")
    print("╰╯╰━┻━━┻━━┻━┻╯╰┻╯╰┻━━╯")
    if admin == "1":
        print()
        print("Kodland Official Admin panel v8.0.3")
        print("OFF-check CODE: TF48G9W7HY776W87")
        while True:
            logadm = input("Please, enter your admin login: ")
            if logadm == logea:
                print("Checking user...")
                time.sleep(1)
                print("Status 0 (founded)")
                passwadm = input(logea + ", please enter your password (its not hidden!!!11!)")
                if passwadm == passwa:
                    print("Checking password...")
                    time.sleep(1)
                    print("Login creditials are correct! Logging you in...")
                    time.sleep(2)
                    print("Success")
                    break
                else:
                    print("Checking password...")
                    time.sleep(1)
                    print("ERR_WRONG_PASS, try again")
            else:
                print("Checking user...")
                time.sleep(1)
                print("ERR_UNDEF_USER, try again")
        print("Loading...")
    else:
        print()
        print("Kodland Official off-web customer panel v8.0.4")
        while True:
            logusr = input("Please, enter your login: ")
            if logusr == logeu:
                print("Checking user...")
                time.sleep(1)
                print("Status 0 (founded)")
                passwusr = input(logeu + ", please enter your password (its not hidden!!!11!)")
                if passwusr == passwu:
                    print("Checking password...")
                    time.sleep(1)
                    print("Login creditials are correct! Logging you in...")
                    time.sleep(2)
                    print("Success")
                    break
                else:
                    print("Checking password...")
                    time.sleep(1)
                    print("ERR_WRONG_PASS, try again")
            else:
                print("Checking user...")
                time.sleep(1)
                print("ERR_UNDEF_USER, try again")
        print("Loading...")
os.system("cls")
while True:
    type = input("Are u admin(1) or customer(0)? Answer: ")
    if type == "1":
        kodland(1)
        break
    elif type == "0":
        kodland(0)
        break
    else:
        print("WRONG_CHOICE_ERR, try again")
        
    

time.sleep(5)
print("Panel is slepping rn")