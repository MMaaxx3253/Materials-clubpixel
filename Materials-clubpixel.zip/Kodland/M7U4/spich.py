import speech_recognition as sr

# obtain audio from the microphone
r = sr.Recognizer()
def spich():
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source) 
        audio = r.listen(source)

        try:
            r_speech = r.recognize_google(audio, language="ru-RU")
            return r_speech
        except sr.UnknownValueError:
            return "Что вы сказали? Я не понял"
        except sr.RequestError as e:
            return f"Ошибка сервиса Google Speech Recognition; {e}"