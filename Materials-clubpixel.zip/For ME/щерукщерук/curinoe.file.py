import time
import os
from colorama import Fore
from colorama import Style
