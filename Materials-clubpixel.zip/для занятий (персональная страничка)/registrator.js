const app = Vue.createApp({
    data() {
        return {
            email: "",
            password: "",
            errorMessage: "",
        };
    },
    methods: {
        async registerUser(event) {
            event.preventDefault();

            const firebaseConfig = {
                apiKey: "YOUR_API_KEY",
                authDomain: "YOUR_AUTH_DOMAIN",
                projectId: "YOUR_PROJECT_ID",
                storageBucket: "YOUR_STORAGE_BUCKET",
                messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
                appId: "YOUR_APP_ID",
            };

            firebase.initializeApp(firebaseConfig);

            const auth = firebase.auth();

            try {
                const userCredential = await auth.createUserWithEmailAndPassword(
                    this.email,
                    this.password
                );
                console.log("Пользователь успешно зарегистрирован!");
                this.errorMessage = "";
            } catch (error) {
                console.error("Ошибка при регистрации:", error);
                this.errorMessage = error.message;
            }
        },
    },
});

app.mount("#app");
